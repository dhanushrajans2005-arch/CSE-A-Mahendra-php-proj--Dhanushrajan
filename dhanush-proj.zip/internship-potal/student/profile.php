<?php
session_start();


$profile = [
    "name" => "Arun Kumar",
    "email" => "arun@example.com",
    "phone" => "9876543210",
    "college" => "Green Valley College",
    "course" => "B.Sc Computer Science",
    "year" => "3rd Year",
    "skills" => "HTML, CSS, PHP, MySQL",
    "bio" => "I am a passionate student interested in web development and software technology."
];

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>My Profile | GreenPath</title>

    <link rel="stylesheet" href="/proxy/9010/css/style.css">

    <style>
        .profile-header {
            background: linear-gradient(120deg, #e5efd8, #f7f6ed);
            padding: 38px;
            border-radius: 18px;
            margin: 30px 0;
            display: flex;
            align-items: center;
            gap: 25px;
            flex-wrap: wrap;
        }

        .profile-avatar {
            width: 95px;
            height: 95px;
            border-radius: 50%;
            background: #24543b;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 36px;
            font-weight: bold;
            font-family: Georgia, serif;
        }

        .profile-details {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 20px;
        }

        .detail-box {
            background: #fff;
            border: 1px solid #dce6d5;
            padding: 20px;
            border-radius: 12px;
            overflow-wrap: anywhere;
        }

        .detail-label {
            color: #68786d;
            font-size: 13px;
            margin-bottom: 5px;
        }

        .detail-value {
            color: #173d2b;
            font-weight: 600;
        }

        .skills {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-top: 10px;
        }

        .skill-tag {
            background: #e5efd8;
            color: #24543b;
            border-radius: 20px;
            padding: 6px 13px;
            font-size: 13px;
            font-weight: 600;
        }

        @media(max-width:600px) {
            .profile-details {
                grid-template-columns: 1fr;
            }

            .profile-header {
                padding: 24px;
            }
        }
    </style>
</head>

<body>

<nav class="navbar">
    <div class="container navbar-inner">
        <a class="logo" href="/proxy/9010/index.php">GreenPath</a>

        <div class="nav-links">
            <a href="/proxy/9010/student/dashboard.php">Dashboard</a>
            <a href="/proxy/9010/student/internships.php">Internships</a>
            <a href="/proxy/9010/student/applications.php">My Applications</a>
            <a href="/proxy/9010/student/profile.php">My Profile</a>
            <a href="/proxy/9010/logout.php">Logout</a>
        </div>
    </div>
</nav>

<main class="container">

    <div class="profile-header">
        <div class="profile-avatar">
            <?= e(strtoupper(substr($profile["name"], 0, 1))) ?>
        </div>

        <div>
            <p class="eyebrow">Student Account</p>
            <h1 class="section-title">
                <?= e($profile["name"]) ?>
            </h1>
            <p><?= e($profile["email"]) ?></p>
            <p>Welcome to your GreenPath profile!</p>
        </div>
    </div>

    <div style="display:flex; justify-content:space-between;
                align-items:center; gap:15px; flex-wrap:wrap;
                margin-bottom:22px;">
        <div>
            <h2>Personal Information</h2>
            <p class="section-subtitle">
                View your education and contact details.
            </p>
        </div>

        <a class="btn"
           href="/proxy/9010/student/edit_profile.php">
            Edit Profile
        </a>
    </div>

    <div class="profile-details">

        <div class="detail-box">
            <div class="detail-label">Full Name</div>
            <div class="detail-value"><?= e($profile["name"]) ?></div>
        </div>

        <div class="detail-box">
            <div class="detail-label">Email Address</div>
            <div class="detail-value"><?= e($profile["email"]) ?></div>
        </div>

        <div class="detail-box">
            <div class="detail-label">Phone Number</div>
            <div class="detail-value"><?= e($profile["phone"]) ?></div>
        </div>

        <div class="detail-box">
            <div class="detail-label">College Name</div>
            <div class="detail-value"><?= e($profile["college"]) ?></div>
        </div>

        <div class="detail-box">
            <div class="detail-label">Course</div>
            <div class="detail-value"><?= e($profile["course"]) ?></div>
        </div>

        <div class="detail-box">
            <div class="detail-label">Year of Study</div>
            <div class="detail-value"><?= e($profile["year"]) ?></div>
        </div>

        <div class="detail-box" style="grid-column:1/-1;">
            <div class="detail-label">Skills</div>

            <div class="skills">
                <?php
                $skills = explode(",", $profile["skills"]);

                foreach ($skills as $skill):
                ?>
                    <span class="skill-tag">
                        <?= e(trim($skill)) ?>
                    </span>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="detail-box" style="grid-column:1/-1;">
            <div class="detail-label">About Me</div>
            <div class="detail-value">
                <?= e($profile["bio"]) ?>
            </div>
        </div>

    </div>

    <div style="margin:30px 0;">
        <a class="btn btn-outline"
           href="/proxy/9010/student/dashboard.php">
            Back to Dashboard
        </a>
    </div>

</main>

<footer class="footer">
    <div class="container">
        <p><strong>GreenPath — Internship Portal</strong></p>
        <p>Discover opportunities. Grow your future.</p>
    </div>
</footer>

</body>
</html>