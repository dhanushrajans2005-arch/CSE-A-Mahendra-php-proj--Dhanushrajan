<?php
session_start();



if (!isset($_SESSION["student_profile"])) {
    $_SESSION["student_profile"] = [
        "name" => "Arun Kumar",
        "email" => "arun@example.com",
        "phone" => "9876543210",
        "college" => "Green Valley College",
        "course" => "B.Sc Computer Science",
        "year" => "3rd Year",
        "skills" => "HTML, CSS, PHP, MySQL",
        "bio" => "I am interested in web development and software technology."
    ];
}

$profile = &$_SESSION["student_profile"];
$success = "";
$error = "";

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $phone = trim($_POST["phone"] ?? "");
    $college = trim($_POST["college"] ?? "");
    $course = trim($_POST["course"] ?? "");
    $year = trim($_POST["year"] ?? "");
    $skills = trim($_POST["skills"] ?? "");
    $bio = trim($_POST["bio"] ?? "");

    if (
        $name === "" ||
        !filter_var($email, FILTER_VALIDATE_EMAIL) ||
        $phone === "" ||
        $college === "" ||
        $course === "" ||
        $year === ""
    ) {
        $error = "Please fill in all required fields correctly.";
    } else {
        $profile["name"] = $name;
        $profile["email"] = $email;
        $profile["phone"] = $phone;
        $profile["college"] = $college;
        $profile["course"] = $course;
        $profile["year"] = $year;
        $profile["skills"] = $skills;
        $profile["bio"] = $bio;

        $success = "Profile updated successfully!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile | GreenPath</title>
    <link rel="stylesheet" href="/proxy/9010/css/style.css">
</head>
<body>

<nav class="navbar">
    <div class="container navbar-inner">
        <a class="logo" href="/proxy/9010/index.php">GreenPath</a>

        <div class="nav-links">
            <a href="/proxy/9010/student/dashboard.php">Dashboard</a>
            <a href="/proxy/9010/student/internships.php">Internships</a>
            <a href="/proxy/9010/student/applications.php">My Applications</a>
            <a href="/proxy/9010/student/profile.php">My Profile</a>
            <a href="/proxy/9010/logout.php">Logout</a>
        </div>
    </div>
</nav>

<main class="container">
    <div class="form-container">
        <p class="eyebrow">Your information</p>
        <h2>Edit Profile</h2>

        <?php if ($success !== ""): ?>
            <div class="alert alert-success">
                <?= e($success) ?>
            </div>
        <?php endif; ?>

        <?php if ($error !== ""): ?>
            <div class="alert alert-error">
                <?= e($error) ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="edit_profile.php">

            <div class="form-group">
                <label for="name">Full Name *</label>
                <input
                    type="text"
                    id="name"
                    name="name"
                    value="<?= e($profile["name"]) ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label for="email">Email Address *</label>
                <input
                    type="email"
                    id="email"
                    name="email"
                    value="<?= e($profile["email"]) ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label for="phone">Phone Number *</label>
                <input
                    type="tel"
                    id="phone"
                    name="phone"
                    value="<?= e($profile["phone"]) ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label for="college">College Name *</label>
                <input
                    type="text"
                    id="college"
                    name="college"
                    value="<?= e($profile["college"]) ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label for="course">Course *</label>
                <input
                    type="text"
                    id="course"
                    name="course"
                    value="<?= e($profile["course"]) ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label for="year">Year of Study *</label>
                <select id="year" name="year" required>
                    <?php
                    $years = [
                        "1st Year",
                        "2nd Year",
                        "3rd Year",
                        "4th Year",
                        "Final Year",
                        "Graduated"
                    ];

                    foreach ($years as $option):
                    ?>
                        <option
                            value="<?= e($option) ?>"
                            <?= $profile["year"] === $option ? "selected" : "" ?>
                        >
                            <?= e($option) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="skills">Skills</label>
                <input
                    type="text"
                    id="skills"
                    name="skills"
                    placeholder="HTML, CSS, PHP, MySQL"
                    value="<?= e($profile["skills"]) ?>"
                >
            </div>

            <div class="form-group">
                <label for="bio">About Me</label>
                <textarea
                    id="bio"
                    name="bio"
                    placeholder="Tell us about yourself..."
                ><?= e($profile["bio"]) ?></textarea>
            </div>

            <button type="submit" style="width:100%;">
                Save Changes
            </button>
        </form>

        <p style="text-align:center; margin-top:18px;">
            <a href="/proxy/9010/student/profile.php">
                Back to My Profile
            </a>
        </p>
    </div>
</main>

<footer class="footer">
    <div class="container">
        <p><strong>GreenPath — Internship Portal</strong></p>
        <p>Discover opportunities. Grow your future.</p>
    </div>
</footer>

</body>
</html>