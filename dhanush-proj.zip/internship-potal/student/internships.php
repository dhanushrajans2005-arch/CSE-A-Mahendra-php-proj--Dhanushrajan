<?php
session_start();

$internships = [
    [
        "id" => 1,
        "title" => "Web Development Intern",
        "company" => "GreenTech Solutions",
        "location" => "Remote",
        "duration" => "3 Months",
        "stipend" => "₹8,000/month",
        "skills" => "HTML, CSS, PHP",
        "description" => "Build responsive websites and work with a development team."
    ],
    [
        "id" => 2,
        "title" => "UI/UX Design Intern",
        "company" => "Creative Nest",
        "location" => "Hybrid",
        "duration" => "2 Months",
        "stipend" => "₹6,000/month",
        "skills" => "Figma, UI Design",
        "description" => "Design user-friendly interfaces and improve user experiences."
    ],
    [
        "id" => 3,
        "title" => "Data Analyst Intern",
        "company" => "Insight Labs",
        "location" => "Chennai",
        "duration" => "3 Months",
        "stipend" => "₹10,000/month",
        "skills" => "Python, SQL, Excel",
        "description" => "Analyse data and help create reports and dashboards."
    ],
    [
        "id" => 4,
        "title" => "Digital Marketing Intern",
        "company" => "Bright Leaf Media",
        "location" => "Remote",
        "duration" => "2 Months",
        "stipend" => "₹5,000/month",
        "skills" => "SEO, Content Writing",
        "description" => "Assist with online campaigns and social media content."
    ],
    [
        "id" => 5,
        "title" => "Java Developer Intern",
        "company" => "Northstar Systems",
        "location" => "Hybrid",
        "duration" => "4 Months",
        "stipend" => "₹9,000/month",
        "skills" => "Java, OOP, SQL",
        "description" => "Develop and test application features with the engineering team."
    ],
    [
        "id" => 6,
        "title" => "Business Analyst Intern",
        "company" => "Pathway Consulting",
        "location" => "Chennai",
        "duration" => "3 Months",
        "stipend" => "₹7,000/month",
        "skills" => "Excel, Research",
        "description" => "Help document requirements and understand business processes."
    ]
];

$search = trim($_GET["search"] ?? "");

$filteredInternships = array_filter(
    $internships,
    function ($internship) use ($search) {
        if ($search === "") {
            return true;
        }

        $searchText = implode(" ", $internship);

        return stripos($searchText, $search) !== false;
    }
);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Available Internships | GreenPath</title>

    <link rel="stylesheet" href="/proxy/9010/css/style.css">

    <style>
        .internship-hero {
            padding: 45px 0;
            background: linear-gradient(120deg, #e5efd8, #f7f6ed);
        }

        .search-form {
            display: flex;
            gap: 12px;
            max-width: 700px;
            margin-top: 22px;
        }

        .search-form input {
            flex: 1;
        }

        .internship-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 22px;
        }

        .internship-card {
            display: flex;
            flex-direction: column;
            background: white;
            border: 1px solid #dce6d5;
            padding: 24px;
            border-radius: 16px;
            box-shadow: 0 8px 25px rgba(23,61,43,.06);
            transition: .2s ease;
        }

        .internship-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 14px 30px rgba(23,61,43,.12);
        }

        .job-tag {
            display: inline-block;
            align-self: flex-start;
            background: #e5efd8;
            color: #24543b;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }

        .internship-card h3 {
            margin-top: 15px;
            margin-bottom: 8px;
        }

        .company-name {
            color: #24543b;
            font-weight: 700;
        }

        .job-description {
            color: #68786d;
            margin: 12px 0;
        }

        .job-detail {
            color: #68786d;
            font-size: 14px;
            margin-top: 7px;
        }

        .job-skills {
            background: #f0f4e9;
            padding: 10px;
            border-radius: 8px;
            margin-top: 15px;
            font-size: 13px;
        }

        .apply-button {
            margin-top: auto;
            padding-top: 18px;
        }

        .apply-button .btn {
            text-align: center;
            width: 100%;
        }

        .no-results {
            padding: 30px;
            background: white;
            border: 1px solid #dce6d5;
            border-radius: 14px;
            text-align: center;
        }

        @media(max-width: 900px) {
            .internship-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }

        @media(max-width: 600px) {
            .internship-grid {
                grid-template-columns: 1fr;
            }

            .search-form {
                flex-direction: column;
            }
        }
    </style>
</head>

<body>

<nav class="navbar">
    <div class="container navbar-inner">

        <a href="../index.php" class="logo">GreenPath.</a>

        <div class="nav-links">
            <a href="dashboard.php">Dashboard</a>
            <a href="internships.php">Internships</a>
            <a href="applications.php">My Applications</a>
            <a href="profile.php">My Profile</a>
            <a href="../logout.php">Logout</a>
        </div>

    </div>
</nav>

<header class="internship-hero">
    <div class="container">

        <p class="eyebrow">DISCOVER YOUR NEXT OPPORTUNITY</p>

        <h1 class="section-title">
            Available Internships
        </h1>

        <p class="section-subtitle">
            Find opportunities, gain experience, and grow your career.
        </p>

        <form method="GET" action="internships.php" class="search-form">

            <input
                type="search"
                name="search"
                value="<?php echo htmlspecialchars($search); ?>"
                placeholder="Search by role, company, location or skill">

            <button type="submit">Search</button>

            <a href="internships.php" class="btn btn-outline">
                Reset
            </a>

        </form>

    </div>
</header>

<main>
    <section>
        <div class="container">

            <h2 class="section-title">Explore Opportunities</h2>

            <p class="section-subtitle">
                Showing <?php echo count($filteredInternships); ?> sample opportunities.
                Real listings will be loaded after database integration.
            </p>

            <?php if (count($filteredInternships) > 0): ?>

                <div class="internship-grid">

                    <?php foreach ($filteredInternships as $internship): ?>

                        <article class="internship-card">

                            <span class="job-tag">
                                <?php echo htmlspecialchars($internship["location"]); ?>
                            </span>

                            <h3>
                                <?php echo htmlspecialchars($internship["title"]); ?>
                            </h3>

                            <p class="company-name">
                                <?php echo htmlspecialchars($internship["company"]); ?>
                            </p>

                            <p class="job-description">
                                <?php echo htmlspecialchars($internship["description"]); ?>
                            </p>

                            <p class="job-detail">
                                <strong>Duration:</strong>
                                <?php echo htmlspecialchars($internship["duration"]); ?>
                            </p>

                            <p class="job-detail">
                                <strong>Stipend:</strong>
                                <?php echo htmlspecialchars($internship["stipend"]); ?>
                            </p>

                            <div class="job-skills">
                                <strong>Skills:</strong>
                                <?php echo htmlspecialchars($internship["skills"]); ?>
                            </div>

                            <div class="apply-button">
                                <a
                                    href="apply.php?job=<?php echo $internship["id"]; ?>"
                                    class="btn">
                                    Apply Now →
                                </a>
                            </div>

                        </article>

                    <?php endforeach; ?>

                </div>

            <?php else: ?>

                <div class="no-results">
                    <h3>No internships found</h3>
                    <p>Try searching with a different keyword or skill.</p>
                    <a href="internships.php" class="btn">
                        View All Internships
                    </a>
                </div>

            <?php endif; ?>

        </div>
    </section>
</main>

<footer class="footer">
    <div class="container">
        <h3 style="color:white;">GreenPath.</h3>
        <p>Learn. Grow. Build your future.</p>
        <p>
            © <?php echo date("Y"); ?> GreenPath Internship Portal
        </p>
    </div>
</footer>

</body>
</html>