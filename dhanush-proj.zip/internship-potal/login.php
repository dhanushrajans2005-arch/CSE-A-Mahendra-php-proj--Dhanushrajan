<?php
session_start();

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";
    $role = $_POST["role"] ?? "";

    

    if ($email === "" || $password === "" || $role === "") {
        $error = "Please fill in all fields.";
    } else {
        $error = "Login is not connected yet. We will connect the database later.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | GreenPath</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<header class="navbar">
    <div class="container navbar-inner">
        <a href="index.php" class="logo">GreenPath.</a>

        <nav class="nav-links">
            <a href="index.php">Home</a>
            <a href="register.php">Create Account</a>
        </nav>
    </div>
</header>

<main class="container">
    <div class="form-container">
        <p class="eyebrow" style="text-align:center;">WELCOME BACK</p>
        <h2>Login to GreenPath</h2>

        <p style="text-align:center;color:#68786d;margin-bottom:25px;">
            Continue your journey towards a brighter career.
        </p>

        <?php if ($error !== ""): ?>
            <div class="alert alert-error">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="login.php">
            <div class="form-group">
                <label for="email">Email Address</label>
                <input
                    type="email"
                    id="email"
                    name="email"
                    placeholder="Enter your email"
                    required
                >
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input
                    type="password"
                    id="password"
                    name="password"
                    placeholder="Enter your password"
                    required
                >
            </div>

            <div class="form-group">
                <label for="role">Login As</label>
                <select id="role" name="role" required>
                    <option value="">Choose your role</option>
                    <option value="student">Student</option>
                    <option value="company">Company</option>
                    <option value="admin">Admin</option>
                </select>
            </div>

            <button type="submit" style="width:100%;">
                Login →
            </button>
        </form>

        <p style="text-align:center;margin-top:22px;">
            Don't have an account?
            <a href="register.php"><strong>Create Account</strong></a>
        </p>

        <p style="text-align:center;margin-top:12px;font-size:13px;color:#68786d;">
            Your next opportunity starts with one step.
        </p>
    </div>
</main>

<footer class="footer">
    <div class="container">
        <p>© <?php echo date("Y"); ?> GreenPath Internship Portal</p>
    </div>
</footer>

</body>
</html>