document.addEventListener("DOMContentLoaded", function () {

    const forms = document.querySelectorAll("form");

    forms.forEach(function (form) {

        form.addEventListener("submit", function (event) {

            let valid = true;

            const requiredFields =
                form.querySelectorAll("[required]");

            requiredFields.forEach(function (field) {

                if (field.value.trim() === "") {

                    valid = false;

                    field.style.border =
                        "2px solid red";

                } else {

                    field.style.border =
                        "1px solid #cbd5e1";

                }

            });


            

            const emailFields =
                form.querySelectorAll(
                    'input[type="email"]'
                );

            emailFields.forEach(function (field) {

                if (field.value.trim() !== "") {

                    const emailPattern =
                        /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

                    if (!emailPattern.test(field.value)) {

                        valid = false;

                        field.style.border =
                            "2px solid red";

                        alert(
                            "Please enter a valid email address."
                        );

                    }

                }

            });


            

            const passwordFields =
                form.querySelectorAll(
                    'input[type="password"]'
                );

            passwordFields.forEach(function (field) {

                if (
                    field.value.length > 0 &&
                    field.value.length < 6
                ) {

                    valid = false;

                    field.style.border =
                        "2px solid red";

                    alert(
                        "Password must contain at least 6 characters."
                    );

                }

            });


            if (!valid) {

                event.preventDefault();

                alert(
                    "Please fill all required fields correctly."
                );

            }

        });

    });

});