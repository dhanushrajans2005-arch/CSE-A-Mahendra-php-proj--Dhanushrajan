<?php
session_start();

if (isset($_SESSION["admin_logged_in"]) && $_SESSION["admin_logged_in"] === true) {
    header("Location: dashboard.php");
    exit;
}

$error = "";

$adminEmail = "admin@greenpath.com";
$adminPassword = "Admin@123";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";

    if (
        $email === $adminEmail &&
        $password === $adminPassword
    ) {
        session_regenerate_id(true);

        $_SESSION["admin_logged_in"] = true;
        $_SESSION["admin_email"] = $email;

        header("Location: dashboard.php");
        exit;
    } else {
        $error = "Invalid email or password. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login | GreenPath Careers</title>
    <link rel="stylesheet" href="/proxy/9010/css/style.css">
</head>
<body>

<nav class="navbar">
    <div class="container navbar-inner">
        <a href="../index.php" class="logo">GreenPath Careers</a>
        <div class="nav-links">
            <a href="../index.php">Home</a>
            <a href="../login.php">User Login</a>
        </div>
    </div>
</nav>

<main class="container">
    <div class="form-container">

        <p class="eyebrow" style="text-align:center;">
            Administration Portal
        </p>

        <h2>Admin Login 🌿</h2>

        <p style="text-align:center; margin-bottom:22px; color:#68786d;">
            Sign in to manage GreenPath Careers.
        </p>

        <?php if ($error !== ""): ?>
            <div class="alert alert-error">
                <?= htmlspecialchars($error, ENT_QUOTES, "UTF-8") ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="form-group">
                <label for="email">Admin Email</label>
                <input
                    type="email"
                    id="email"
                    name="email"
                    placeholder="Enter admin email"
                    autocomplete="username"
                    required
                >
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input
                    type="password"
                    id="password"
                    name="password"
                    placeholder="Enter admin password"
                    autocomplete="current-password"
                    required
                >
            </div>

            <button type="submit" style="width:100%;">
                Login to Dashboard
            </button>
        </form>

        <p style="text-align:center; margin-top:22px;">
            <a href="../index.php">← Back to Home</a>
        </p>

    </div>
</main>

<footer class="footer">
    <div class="container">
        <p>© 2026 GreenPath Careers</p>
        <p>Growing careers, naturally.</p>
    </div>
</footer>

</body>
</html>