<?php
session_start();

if (!isset($_SESSION["admin_logged_in"]) || $_SESSION["admin_logged_in"] !== true) {
    header("Location: login.php");
    exit;
}


$internships = [
    [
        "id" => 1,
        "title" => "PHP Web Developer Intern",
        "company" => "GreenTech Solutions",
        "location" => "Chennai",
        "duration" => "3 Months",
        "stipend" => "₹8,000/month",
        "skills" => "PHP, HTML, CSS, MySQL"
    ],
    [
        "id" => 2,
        "title" => "Frontend Developer Intern",
        "company" => "Bright Future Technologies",
        "location" => "Coimbatore",
        "duration" => "2 Months",
        "stipend" => "₹5,000/month",
        "skills" => "HTML, CSS, JavaScript"
    ],
    [
        "id" => 3,
        "title" => "Python Developer Intern",
        "company" => "NatureSoft Pvt Ltd",
        "location" => "Remote",
        "duration" => "6 Months",
        "stipend" => "₹10,000/month",
        "skills" => "Python, SQL, Django"
    ]
];

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}

$search = trim($_GET["search"] ?? "");

if ($search !== "") {
    $internships = array_values(array_filter(
        $internships,
        function ($internship) use ($search) {
            return stripos($internship["title"], $search) !== false
                || stripos($internship["company"], $search) !== false
                || stripos($internship["location"], $search) !== false
                || stripos($internship["skills"], $search) !== false;
        }
    ));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Internships | GreenPath Careers</title>
    <link rel="stylesheet" href="/proxy/9010/css/style.css">
</head>

<body>

<nav class="navbar">
    <div class="container navbar-inner">
        <a href="dashboard.php" class="logo">GreenPath Careers</a>

        <div class="nav-links">
            <a href="dashboard.php">Dashboard</a>
            <a href="manage_students.php">Students</a>
            <a href="manage_companies.php">Companies</a>
            <a href="manage_internships.php">Internships</a>
            <a href="manage_applications.php">Applications</a>
            <a href="../logout.php">Logout</a>
        </div>
    </div>
</nav>

<section>
    <div class="container">

        <p class="eyebrow">Admin Management</p>
        <h1 class="section-title">Manage Internships 💼</h1>

        <p class="section-subtitle">
            View and search internship opportunities.
        </p>

        <div class="card">
            <form method="GET" action="">
                <div class="form-group">
                    <label for="search">Search Internships</label>
                    <input
                        type="search"
                        id="search"
                        name="search"
                        placeholder="Search title, company, location or skills"
                        value="<?= e($search) ?>"
                    >
                </div>

                <button type="submit">Search</button>

                <a href="manage_internships.php" class="btn btn-outline">
                    Clear
                </a>
            </form>
        </div>

        <p style="margin-top:24px;">
            Internships found: <strong><?= count($internships) ?></strong>
        </p>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Internship</th>
                        <th>Company</th>
                        <th>Location</th>
                        <th>Duration</th>
                        <th>Stipend</th>
                        <th>Required Skills</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if (count($internships) > 0): ?>
                        <?php foreach ($internships as $internship): ?>
                            <tr>
                                <td><?= e($internship["id"]) ?></td>

                                <td>
                                    <strong><?= e($internship["title"]) ?></strong>
                                </td>

                                <td><?= e($internship["company"]) ?></td>
                                <td><?= e($internship["location"]) ?></td>
                                <td><?= e($internship["duration"]) ?></td>
                                <td><?= e($internship["stipend"]) ?></td>
                                <td><?= e($internship["skills"]) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" style="text-align:center;">
                                No internships found.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <a href="dashboard.php" class="btn btn-outline">
            ← Back to Dashboard
        </a>

    </div>
</section>

<footer class="footer">
    <div class="container">
        <p>© 2026 GreenPath Careers</p>
        <p>Growing careers, naturally.</p>
    </div>
</footer>

</body>
</html>