<?php
$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";
    $confirm_password = $_POST["confirm_password"] ?? "";
    $role = $_POST["role"] ?? "";

    if (
        $name === "" ||
        $email === "" ||
        $password === "" ||
        $confirm_password === "" ||
        $role === ""
    ) {
        $error = "Please fill in all fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } elseif (strlen($password) < 8) {
        $error = "Password must contain at least 8 characters.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } elseif (!in_array($role, ["student", "company"], true)) {
        $error = "Please select a valid account type.";
    } else {
        $success = "Form validation successful! Database registration will be added later.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account | GreenPath</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<header class="navbar">
    <div class="container navbar-inner">
        <a href="index.php" class="logo">GreenPath.</a>

        <nav class="nav-links">
            <a href="index.php">Home</a>
            <a href="login.php">Login</a>
        </nav>
    </div>
</header>

<main class="container">
    <div class="form-container">
        <p class="eyebrow" style="text-align:center;">START YOUR JOURNEY</p>
        <h2>Create Account</h2>

        <p style="text-align:center;color:#68786d;margin-bottom:25px;">
            Join GreenPath and discover new opportunities.
        </p>

        <?php if ($error !== ""): ?>
            <div class="alert alert-error">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <?php if ($success !== ""): ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($success); ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="register.php">
            <div class="form-group">
                <label for="name">Full Name / Company Name</label>
                <input
                    type="text"
                    id="name"
                    name="name"
                    placeholder="Enter your name"
                    value="<?php echo htmlspecialchars($_POST["name"] ?? ""); ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label for="email">Email Address</label>
                <input
                    type="email"
                    id="email"
                    name="email"
                    placeholder="Enter your email"
                    value="<?php echo htmlspecialchars($_POST["email"] ?? ""); ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label for="role">Register As</label>
                <select id="role" name="role" required>
                    <option value="">Choose account type</option>
                    <option value="student"
                        <?php echo (($_POST["role"] ?? "") === "student") ? "selected" : ""; ?>>
                        Student
                    </option>
                    <option value="company"
                        <?php echo (($_POST["role"] ?? "") === "company") ? "selected" : ""; ?>>
                        Company
                    </option>
                    <option value="admin"
                        <?php echo (($_POST["role"] ?? "") === "admin") ? "selected" : ""; ?>>
                        Admin
                    </option>
                </select>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input
                    type="password"
                    id="password"
                    name="password"
                    placeholder="At least 8 characters"
                    minlength="8"
                    required
                >
            </div>

            <div class="form-group">
                <label for="confirm_password">Confirm Password</label>
                <input
                    type="password"
                    id="confirm_password"
                    name="confirm_password"
                    placeholder="Re-enter your password"
                    minlength="8"
                    required
                >
            </div>

            <button type="submit" style="width:100%;">
                Create My Account →
            </button>
        </form>

        <p style="text-align:center;margin-top:22px;">
            Already registered?
            <a href="login.php"><strong>Login here</strong></a>
        </p>
    </div>
</main>

<footer class="footer">
    <div class="container">
        <p>© <?php echo date("Y"); ?> GreenPath Internship Portal</p>
    </div>
</footer>

</body>
</html>