<?php
session_start();


$applicants = [
    [
        "name" => "Dhanushrajan S",
        "email" => "dhanushrajans2005@gmail.com",
        "college" => "Mahendra College of Engineering",
        "internship" => "Web Development Intern",
        "skills" => "HTML, CSS, PHP",
        "applied_date" => "2026-10-02",
        "status" => "Pending"
    ],
    [
        "name" => "Bharanidharan K",
        "email" => "bharanidharan0403@gmail.com",
        "college" => "Mahendra College of Engineering",
        "internship" => "PHP Developer Intern",
        "skills" => "PHP, MySQL",
        "applied_date" => "2026-10-03",
        "status" => "Shortlisted"
    ],
    [
        "name" => "Deepak Raj",
        "email" => "deera@gmail.com",
        "college" => "Mahendra College of Engineering",
        "internship" => "Web Development Intern",
        "skills" => "JavaScript, HTML, CSS",
        "applied_date" => "2026-10-04",
        "status" => "Pending"
    ],
    [
        "name" => "Dharnish",
        "email" => "dharnish@gmail.com",
        "college" => "Sona College",
        "internship" => "UI/UX Design Intern",
        "skills" => "Figma, UI Design",
        "applied_date" => "2026-10-05",
        "status" => "Rejected"
    ]
];

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}

$filter = $_GET["status"] ?? "All";

$allowedStatuses = ["All", "Pending", "Shortlisted", "Accepted", "Rejected"];

if (!in_array($filter, $allowedStatuses, true)) {
    $filter = "All";
}

$filteredApplicants = array_filter(
    $applicants,
    function ($applicant) use ($filter) {
        return $filter === "All" || $applicant["status"] === $filter;
    }
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Applicants | GreenPath</title>

    <link rel="stylesheet" href="/proxy/9010/css/style.css">

    <style>
        .page-heading {
            padding: 38px 0 10px;
        }

        .filter-bar {
            background: #fff;
            border: 1px solid #dce6d5;
            border-radius: 13px;
            padding: 18px;
            margin: 25px 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
        }

        .filter-bar form {
            display: flex;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
        }

        .filter-bar select {
            min-width: 160px;
        }

        .applicant-card {
            background: #fff;
            border: 1px solid #dce6d5;
            border-radius: 15px;
            padding: 23px;
            margin-bottom: 18px;
            box-shadow: 0 8px 25px rgba(23,61,43,.06);
        }

        .applicant-top {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 15px;
            flex-wrap: wrap;
        }

        .applicant-card p {
            color: #68786d;
            margin-top: 5px;
            overflow-wrap: anywhere;
        }

        .applicant-info {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 12px;
            margin-top: 18px;
            padding: 15px;
            border-radius: 10px;
            background: #f7f6ed;
        }

        .applicant-actions {
            margin-top: 18px;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .status.shortlisted {
            background: #dce8fb;
            color: #254d85;
        }

        .status.accepted {
            background: #d9f0d7;
            color: #205b32;
        }

        .status.rejected {
            background: #fce8e5;
            color: #963d32;
        }

        .empty-state {
            background: #fff;
            border: 1px dashed #a8c686;
            border-radius: 14px;
            padding: 35px;
            text-align: center;
        }

        @media(max-width:600px) {
            .applicant-info {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>

<nav class="navbar">
    <div class="container navbar-inner">
        <a class="logo" href="/proxy/9010/index.php">GreenPath</a>

        <div class="nav-links">
            <a href="/proxy/9010/company/dashboard.php">Dashboard</a>
            <a href="/proxy/9010/company/profile.php">Company Profile</a>
            <a href="/proxy/9010/company/internships.php">My Internships</a>
            <a href="/proxy/9010/company/add_internship.php">Add Internship</a>
            <a href="/proxy/9010/company/applicants.php">Applicants</a>
            <a href="/proxy/9010/logout.php">Logout</a>
        </div>
    </div>
</nav>

<main class="container">

    <div class="page-heading">
        <p class="eyebrow">Find your next talent</p>
        <h1 class="section-title">Manage Applicants</h1>
        <p class="section-subtitle">
            Review student applications for your internship opportunities.
        </p>
    </div>

    <section style="padding-top:15px;">

        <div class="stats-grid">
            <div class="stat-card">
                <p>Total Applicants</p>
                <div class="stat-number">
                    <?= count($applicants) ?>
                </div>
            </div>

            <div class="stat-card">
                <p>Pending</p>
                <div class="stat-number">
                    <?= count(array_filter($applicants, function($a) {
                        return $a["status"] === "Pending";
                    })) ?>
                </div>
            </div>

            <div class="stat-card">
                <p>Shortlisted</p>
                <div class="stat-number">
                    <?= count(array_filter($applicants, function($a) {
                        return $a["status"] === "Shortlisted";
                    })) ?>
                </div>
            </div>

            <div class="stat-card">
                <p>Accepted</p>
                <div class="stat-number">
                    <?= count(array_filter($applicants, function($a) {
                        return $a["status"] === "Accepted";
                    })) ?>
                </div>
            </div>
        </div>

        <div class="filter-bar">
            <div>
                <h3>Student Applications</h3>
                <p>
                    Showing <?= count($filteredApplicants) ?> application(s)
                </p>
            </div>

            <form method="GET" action="applicants.php">
                <label for="status">Filter Status</label>

                <select id="status" name="status">
                    <?php foreach ($allowedStatuses as $item): ?>
                        <option
                            value="<?= e($item) ?>"
                            <?= $filter === $item ? "selected" : "" ?>
                        >
                            <?= e($item) ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <button type="submit">Filter</button>
            </form>
        </div>

        <?php if (empty($filteredApplicants)): ?>

            <div class="empty-state">
                <h3>No Applicants Found</h3>
                <p>There are no applications matching this status.</p>
                <br>
                <a class="btn"
                   href="/proxy/9010/company/applicants.php">
                    View All Applicants
                </a>
            </div>

        <?php else: ?>

            <?php foreach ($filteredApplicants as $applicant): ?>

                <?php
                $statusClass = strtolower($applicant["status"]);
                ?>

                <article class="applicant-card">

                    <div class="applicant-top">
                        <div>
                            <h3><?= e($applicant["name"]) ?></h3>
                            <p><?= e($applicant["email"]) ?></p>
                        </div>

                        <span class="status <?= e($statusClass) ?>">
                            <?= e($applicant["status"]) ?>
                        </span>
                    </div>

                    <div class="applicant-info">
                        <div>
                            <strong>Internship</strong>
                            <p><?= e($applicant["internship"]) ?></p>
                        </div>

                        <div>
                            <strong>College</strong>
                            <p><?= e($applicant["college"]) ?></p>
                        </div>

                        <div>
                            <strong>Skills</strong>
                            <p><?= e($applicant["skills"]) ?></p>
                        </div>

                        <div>
                            <strong>Applied Date</strong>
                            <p><?= e($applicant["applied_date"]) ?></p>
                        </div>
                    </div>

                    <div class="applicant-actions">
                        <a class="btn btn-outline"
                           href="mailto:<?= e($applicant["email"]) ?>">
                            Contact Student
                        </a>
                    </div>

                </article>

            <?php endforeach; ?>

        <?php endif; ?>

        <div style="margin-top:25px;">
            <a class="btn"
               href="/proxy/9010/company/dashboard.php">
                Back to Dashboard
            </a>
        </div>

    </section>
</main>

<footer class="footer">
    <div class="container">
        <p><strong>GreenPath — Internship Portal</strong></p>
        <p>Connecting companies with future talent.</p>
    </div>
</footer>

</body>
</html>