<?php
session_start();

if (!isset($_SESSION["company_logged_in"])) {
    header("Location: ../login.php");
    exit;
}

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}

$defaultProfile = [
    "name" => $_SESSION["company_name"] ?? "GreenTech Solutions",
    "email" => "hr@greentech.example",
    "phone" => "",
    "website" => "",
    "location" => "Chennai",
    "industry" => "Information Technology",
    "description" => "We help students gain practical experience through internships and real-world projects.",
    "size" => "11-50 Employees"
];

$profile = array_merge(
    $defaultProfile,
    $_SESSION["company_profile"] ?? []
);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Company Profile | GreenPath Careers</title>
    <link rel="stylesheet" href="/proxy/9010/css/style.css">
</head>
<body>

<nav class="navbar">
    <div class="container navbar-inner">
        <a href="dashboard.php" class="logo">GreenPath Careers</a>

        <div class="nav-links">
            <a href="dashboard.php">Dashboard</a>
            <a href="internships.php">My Internships</a>
            <a href="applicants.php">Applicants</a>
            <a href="../logout.php">Logout</a>
        </div>
    </div>
</nav>

<section>
    <div class="container">

        <p class="eyebrow">Company Information</p>
        <h1 class="section-title">My Company Profile</h1>
        <p class="section-subtitle">
            Manage your company information and help students learn about you.
        </p>

        <div class="card" style="max-width:850px; margin:auto;">

            <div style="display:flex; align-items:center; gap:20px; flex-wrap:wrap; margin-bottom:25px;">
                <div style="
                    width:80px;
                    height:80px;
                    border-radius:18px;
                    background:#e5efd8;
                    display:flex;
                    align-items:center;
                    justify-content:center;
                    font-size:36px;">
                    🌿
                </div>

                <div>
                    <h2><?= e($profile["name"]) ?></h2>
                    <p><?= e($profile["industry"] ?: "Industry not provided") ?></p>
                    <span class="badge">
                        <?= e($profile["size"] ?: "Company size not provided") ?>
                    </span>
                </div>
            </div>

            <div class="table-wrapper">
                <table>
                    <tbody>
                        <tr>
                            <th>Company Name</th>
                            <td><?= e($profile["name"]) ?></td>
                        </tr>
                        <tr>
                            <th>Email Address</th>
                            <td><?= e($profile["email"]) ?></td>
                        </tr>
                        <tr>
                            <th>Phone Number</th>
                            <td><?= e($profile["phone"] ?: "Not provided") ?></td>
                        </tr>
                        <tr>
                            <th>Website</th>
                            <td>
                                <?php if (!empty($profile["website"])): ?>
                                    <a href="<?= e($profile["website"]) ?>"
                                       target="_blank" rel="noopener noreferrer">
                                        <?= e($profile["website"]) ?>
                                    </a>
                                <?php else: ?>
                                    Not provided
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Location</th>
                            <td><?= e($profile["location"] ?: "Not provided") ?></td>
                        </tr>
                        <tr>
                            <th>Industry</th>
                            <td><?= e($profile["industry"] ?: "Not provided") ?></td>
                        </tr>
                        <tr>
                            <th>Company Size</th>
                            <td><?= e($profile["size"] ?: "Not provided") ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <h3>About Our Company</h3>
            <p style="white-space:pre-wrap; margin-bottom:25px;"><?= e($profile["description"] ?: "No company description added yet.") ?></p>

            <a href="edit_profile.php" class="btn">✏️ Edit Profile</a>
            <a href="dashboard.php" class="btn btn-outline" style="margin-left:8px;">
                Back to Dashboard
            </a>

        </div>
    </div>
</section>

<footer class="footer">
    <div class="container">
        <p>© 2026 GreenPath Careers</p>
        <p>Growing careers, naturally.</p>
    </div>
</footer>

</body>
</html>