<?php
echo "Company folder is working!";
?>
