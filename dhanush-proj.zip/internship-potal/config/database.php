<?php

$host = "db01.dbhost.dev";
$port = 5051;
$dbname = "db_455pcacb7";
$username = "user_455pcacb7";
$password = "p455pcacb7";
try {
    $dsn = "mysql:host=$host;port=$port;dbname=$dbname;charset=utf8mb4";

    $pdo = new PDO($dsn, $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false
    ]);

} catch (PDOException $e) {
    error_log("Database connection error: " . $e->getMessage());

    http_response_code(500);
    exit("Database connection failed. Please check your database settings.");
}